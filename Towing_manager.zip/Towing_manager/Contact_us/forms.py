from django import forms
from .models import *

class Contact_Us_Form(forms.ModelForm):
    class Meta:
        model = ContactUs
        fields = "__all__"
        widgets = {
            'name' : forms.TextInput(attrs={
                'class':"form-control",
                'id':"login-name",
                'placeholder':"Name",
                'style':"border-radius: 10px;"
            }),
            'email' : forms.EmailInput(attrs={
                'class':"form-control",
                'id':"login-name",
                'placeholder':"Email",
                'style':"border-radius: 10px;"
            }),
            'phone' : forms.NumberInput(attrs={
                'class':"form-control",
                'id':"login-name",
                'placeholder':"Phone number",
                'style':"border-radius: 10px;"
            }),
            'address' : forms.TextInput(attrs={
                'class':"form-control",
                'id':"login-name",
                'placeholder':"Address",
                'style':"border-radius: 10px;"
            }),
            'area' : forms.Select(attrs={
                'class':"form-control",
                'id':"login-name",
                'placeholder':"Select Area",
                'style':"border-radius: 10px;"
            }),
            'pincode' : forms.NumberInput(attrs={
                'class':"form-control",
                'id':"login-name",
                'placeholder':"Pincode",
                'style':"border-radius: 10px;"
            }),
            'message' : forms.TextInput(attrs={
                'class':"form-control",
                'id':"login-name",
                'placeholder':"Message",
                'style':"border-radius: 10px;"
            }),
                        
        }