from django.db import models
from TowingAdmin.models import area_data
# Create your models here.
class ContactUs(models.Model):
    name = models.CharField(max_length=200)
    email = models.EmailField(max_length=200)
    phone = models.IntegerField()
    address = models.TextField(max_length=200)
    area = models.ForeignKey(area_data,on_delete=models.CASCADE)
    pincode = models.IntegerField()
    message = models.TextField(max_length=1000)
    def __str__(self):
        return self.name