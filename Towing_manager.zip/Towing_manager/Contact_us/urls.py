from django.urls import path
from .views import * 

app_name = "Contact"

urlpatterns = [
    path('contact_us_fun/',contact_us_fun,name="contact_us")
]