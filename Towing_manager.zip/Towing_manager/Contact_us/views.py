from django.shortcuts import render,redirect
from django.contrib import messages
from .models import *
from .forms import *

# Create your views here.
def contact_us_fun(request):
    if request.method == 'POST':
        form = Contact_Us_Form(request.POST)
        if form.is_valid():
            form.save()
            return redirect('Customer:index')
        else:
            messages.error(request,"Something went wrong.")
            return redirect('Contact:contact_us')
    else:
        form = Contact_Us_Form()
    template = 'ContactUs/contact_us.html'
    return render(request,template,{'form':form})
    