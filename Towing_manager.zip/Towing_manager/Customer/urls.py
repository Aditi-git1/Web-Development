from django.urls import path
from .views import *

app_name = 'Customer'
urlpatterns = [
    path('',index,name="index"),
    path('search_result/',search,name="search"),
    path('services/',services,name="services"),
    path('view_service/<str:choose_service>/',view_service,name="view_service")
]
