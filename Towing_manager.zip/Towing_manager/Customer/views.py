from django.shortcuts import render
from TowingAdmin.models import *
from ServiceProvider.models import ServiceProviderServices,AddServices
# Create your views here.
def index(request):
    template = 'index.html'
    return render(request,template) 

def search(request):
    query = request.GET.get('query')
    query = query.upper()
    try:
        result_data = add_number_plate.objects.get(number_plate__iexact=query)
        full_data = Master_data.objects.get(number_plate__iexact=query)
    except:
        result_data = add_number_plate.objects.none()
        full_data = Master_data.objects.none()
    return render(request,'search_result.html',{'result':result_data,'full':full_data,'query':query})

def services(request):  
    return(render(request,"Provider/all_services.html"))

def view_service(request,choose_service):
    service = ServiceProviderServices.objects.get(service_name=str(choose_service))
    service_provider = AddServices.objects.filter(my_services=service)
    if request.method == "GET":
        area_name = request.GET.get('area')
        try:
            service_area = area_data.objects.filter(area__icontains = str(area_name))
            for i in service_area:
                service_provider = (AddServices.objects.filter(provider__provider_admin_profile__provider_area__area__icontains=i.area) and AddServices.objects.filter(my_services=service))
        except:
            service_provider = None
    return render(request,"Provider/view_service.html",{'service_provider':service_provider})
