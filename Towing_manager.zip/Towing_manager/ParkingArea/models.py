from django.db import models

# Create your models here.
class parking_area(models.Model):
    parking_name = models.CharField(max_length=100)
    address = models.TextField()
    zipcode = models.IntegerField()
    latitude = models.FloatField()
    longitude = models.FloatField()

    def __str__(self):
        return self.parking_name