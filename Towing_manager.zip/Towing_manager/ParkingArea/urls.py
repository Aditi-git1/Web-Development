from django.urls import path
from .views import *

app_name = "Parking"

urlpatterns = [
    path('parking_zone/',parking_zone,name="parking_zone")
]