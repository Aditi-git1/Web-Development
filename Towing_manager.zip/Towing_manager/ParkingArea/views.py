from django.shortcuts import render
from .models import *
from TowingAdmin.models import area_data

# Create your views here.
def parking_zone(request):
    if request.method == 'GET':
        area_name = request.GET.get('area')
        zip = None
        try:
            pincode = area_data.objects.filter(area__icontains = str(area_name))
            for i in pincode:
                zip = parking_area.objects.filter(zipcode__icontains=i.pincode)
        except:
            pincode = None
            zip = parking_area.objects.none
        template = 'ParkingArea/parking_area.html'
        return render(request,template,{'zip':zip})
