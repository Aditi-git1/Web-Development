from django.db import models

# Create your models here.
class paid_data_users(models.Model):
    number_plate = models.CharField(max_length=50, primary_key=True)
    towed_from = models.CharField(max_length=100)
    towed_from_area = models.CharField(max_length=100)
    towed_date = models.CharField(max_length=100)

    def __str__(self):
        return (self.number_plate)