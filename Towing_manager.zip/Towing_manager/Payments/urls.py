from django.urls import path
from .views import *

app_name = "Payment"

urlpatterns = [
    path('payments/<int:buyer_id>/<str:my_result>/',process_payment,name="process_payment"),
    path('payment_done/',payment_done,name="payment_done"),
    path('show_invoice/<str:number_plate>/',show_invoice,name="show_invoice")
]