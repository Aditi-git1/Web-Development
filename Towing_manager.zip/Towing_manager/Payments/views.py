from django.shortcuts import render, redirect
from TowingAdmin.models import add_number_plate,Master_data
import json
from .models import *
from django.http import JsonResponse
import os
from twilio.rest import Client

def process_payment(request,buyer_id,my_result):
    try:
        num_data = Master_data.objects.get(pk=buyer_id)
        data = add_number_plate.objects.get(pk=my_result)
    except:
        return redirect('Customer:index')
    return render(request,"Payments/process_payment.html",{'result':data})

def payment_done(request):
    body = json.loads(request.body)
    print('BODY:', body)
    paid = add_number_plate.objects.get(number_plate__iexact=body['productId'])
    final_paid = paid_data_users(number_plate=paid.number_plate,towed_from=paid.towed_from,towed_from_area=paid.towed_from_area.area,towed_date=paid.towed_date)
    final_paid.save()
    trial = Master_data.objects.get(number_plate__iexact = paid.number_plate)
    msg = "\n\nHello " + str(trial.full_name).strip() + ",\nPayment Successful for " + str(trial.number_plate).strip() + \
        " and 100₹ debited from your account.\nYou can collect your vehicle and be aware from next time to park your vehicle in 'NO PARKING ZONE'.\nYou can find your nearest parking area from here: http://127.0.0.1:8000/parking_near_me/parking_zone/"+"\nWe have sent you a mail of invoice."
    account_sid = 'AC125baf10d23e118ec34874b5a49dd332'
    auth_token = 'fd87f63b099f62f81afc0dde1443f891'
    client = Client(account_sid, auth_token)
    message = client.messages.create(
        body=msg,
        from_='+14345108490',
        to='+919409172899'
    )
    print('Message Sent :- ', message.sid)
    paid.delete()
    return JsonResponse('Payment completed!', safe=False)

def show_invoice(request, number_plate):
    try:
        result = paid_data_users.objects.get(number_plate__iexact=number_plate)
        master = Master_data.objects.get(number_plate__iexact = result.number_plate )
    except:
        return redirect('Customer:index')
    return render(request, 'Payments/show_invoice.html', {'result': result,'master':master})