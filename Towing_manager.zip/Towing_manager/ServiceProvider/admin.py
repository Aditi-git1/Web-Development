from django.contrib import admin
from .models import *
# Register your models here.
admin.site.register(provider_admin)
admin.site.register(Provider_admin_profile)
admin.site.register(ServiceProviderServices)
admin.site.register(AddServices)