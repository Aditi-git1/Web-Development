from django import forms
from .models import *
from django.contrib.auth.forms import UserCreationForm, AuthenticationForm
from django.contrib.auth.models import User

class provider_signup_form(UserCreationForm):
    username = forms.CharField(required=True,widget=forms.TextInput(attrs={
        'class':"form-control",
        'id':"login-name",
        'placeholder':"Username",
        'style':"border-radius: 10px;"
    }))
    email = forms.EmailField(required=True,widget=forms.EmailInput(attrs={
        'class':"form-control",
        'id':"login-name",
        'placeholder':"Email",
        'style':"border-radius: 10px;"
    }))
    password1 = forms.CharField(required=True,widget=forms.PasswordInput(attrs={
        'class':"form-control",
        'id':"login-name",
        'placeholder':"Password",
        'style':"border-radius: 10px;"
    }))
    password2 = forms.CharField(required=True,widget=forms.PasswordInput(attrs={
        'class':"form-control",
        'id':"login-name",
        'placeholder':"Confirm Password",
        'style':"border-radius: 10px;"
    }))
    class Meta:
        model = User
        fields = ['username','email','password1','password2']

class Provider_Login_form(AuthenticationForm):
    username = forms.CharField(required=True,label_suffix="", widget=forms.TextInput(attrs={
        'id':"form3Example1cg",
        'class':"form-control form-control-lg",
        'placeholder' : 'Enter your Username'
    }))
    password = forms.CharField(required=True, label="Password", label_suffix="", widget=forms.PasswordInput(attrs={
        'id':"form3Example1cg",
        'class':"form-control form-control-lg",
        'placeholder' : 'Enter your Password'
    }))
    class Meta:
        model = User
        fields = ['username']

class Provider_Verification_Email_Form(forms.ModelForm):
    email = forms.EmailField(required=True,widget=forms.EmailInput(attrs={
        'class':"form-control",
        'id':"login-name",
        'placeholder':"Email",
        'style':"border-radius: 10px;"
    }))
    class Meta:
        model = User
        fields = ['email']


class Provider_Forgot_password_form(forms.ModelForm):
    email = forms.EmailField(required=True,widget=forms.EmailInput(attrs={
        'class':"form-control",
        'id':"login-name",
        'placeholder':"Email",
        'style':"border-radius: 10px;"
    }))
    class Meta:
        model = User
        fields = ['email']

class Provider_profile_form(forms.ModelForm):
    class Meta:
        model = Provider_admin_profile
        exclude = ['user']
        widgets = {
            'provider_phone': forms.NumberInput(attrs={
                    'class':"form-control",
                    'id':"login-name",
                    'placeholder':"Phone Number",
                    'style':"border-radius: 10px;"
            }) ,
            'provider_address': forms.Textarea(attrs={
                    'class':"form-control",
                    'id':"login-name",
                    'placeholder':"Address",
                    'style':"border-radius: 10px;"
            }) ,
            'provider_area': forms.Select(attrs={
                    'class':"form-control",
                    'id':"login-name",
                    'placeholder':"Area",
                    'style':"border-radius: 10px;"
            }) ,
            'provider_website': forms.URLInput(attrs={
                    'class':"form-control",
                    'id':"login-name",
                    'placeholder':"Website",
                    'style':"border-radius: 10px;"
            }) ,
            'image' : forms.FileInput(attrs={
                    'class':"form-control",
                    'id':"login-name",
                    'placeholder':"Upload an Image",
                    'style':"border-radius: 10px;"
            })
        }

class Provider_user_form(forms.ModelForm):
    username = forms.CharField(disabled=True,widget=forms.TextInput(attrs={
                    'class':"form-control",
                    'id':"login-name",
                    'placeholder':"Username",
                    'style':"border-radius: 10px;",
            }))
    email = forms.EmailField(disabled=True,widget=forms.EmailInput(attrs={
                    'class':"form-control",
                    'id':"login-name",
                    'placeholder':"Email",
                    'style':"border-radius: 10px;",
            }))
    class Meta:
        model = User
        fields = ['username','email','first_name','last_name']
        widgets = {
            'first_name': forms.TextInput(attrs={
                    'class':"form-control",
                    'id':"login-name",
                    'placeholder':"Company Name",
                    'style':"border-radius: 10px;"
            }) ,
            'last_name': forms.TextInput(attrs={
                    'class':"form-control",
                    'id':"login-name",
                    'placeholder':"Company Admin Name",
                    'style':"border-radius: 10px;"
            })
        }

class AddServicesForm(forms.ModelForm):
    class Meta:
        model = AddServices
        fields = ['my_services','my_services_desc']
        widgets = {
            'my_services': forms.Select(attrs={
            'class':"form-control",
            'id':"login-name",
            'placeholder':"My Services",
            'style':"border-radius: 10px;"
            }) ,
            'my_services_desc': forms.Textarea(attrs={
            'class':"form-control",
            'id':"login-name",
            'placeholder':"Add Service Description",
            'style':"border-radius: 10px;"
            }) ,
        }