from django.db import models
from django.contrib.auth.models import User
from django.db.models.signals import post_save
from django.dispatch import receiver
from TowingAdmin.models import area_data
# Create your models here.

class provider_admin(models.Model):
    user = models.OneToOneField(User,on_delete=models.CASCADE,primary_key=True)

    def __str__(self):
        return str(self.user)

class Provider_admin_profile(models.Model):
    user = models.OneToOneField(provider_admin,on_delete=models.CASCADE,primary_key=True)
    provider_phone = models.IntegerField(null=True,blank=True)
    provider_address = models.TextField(null=True,blank = True)
    provider_area = models.ForeignKey(area_data,on_delete=models.CASCADE,null=True,blank=True)
    provider_website = models.URLField(null=True,blank=True)
    image = models.ImageField(upload_to="Company Logo",null=True,blank=True)

    def __str__(self):
        return str(self.user)

@receiver(post_save,sender=provider_admin)
def create_Provider_admin_profile(sender,instance,created,**kwargs):
    if created:
        Provider_admin_profile.objects.create(user=instance)

@receiver(post_save,sender=provider_admin)
def save_user_Provider_admin_profile(sender,instance,**kwargs):
    instance.provider_admin_profile.save()

class ServiceProviderServices(models.Model):
    service_name = models.CharField(max_length=200)
    def __str__(self):
        return self.service_name

class AddServices(models.Model):
    provider = models.ForeignKey(provider_admin,on_delete=models.CASCADE)
    my_services = models.ForeignKey(ServiceProviderServices,on_delete=models.CASCADE)
    my_services_desc = models.TextField()
    created_date = models.DateTimeField(auto_now_add=True)
    def __str__(self):
        return str(self.my_services)