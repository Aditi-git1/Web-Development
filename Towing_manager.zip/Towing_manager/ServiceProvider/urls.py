from django.urls import path
from .views import *

app_name = "Provider"

urlpatterns = [
    path('',provider_register,name="provider_register"),
    path('provider_login/',provider_login,name="provider_login"),
    path('provider_profile/',provider_profile,name="provider_profile"),
    path('provider_email_verification/',provider_email_verification,name="provider_email_verification"),
    path('provider_logout/',provider_logout,name="provider_logout"),
    path('provider_set_password/',provider_set_password,name="provider_set_password"),
    path('provider_forgot_password_function/',provider_forgot_password_function,name="provider_forgot_password_function"),
    path('provider_verify_otp/',provider_verify_otp,name="provider_verify_otp"),
    path('provider_reset_password/',provider_reset_password,name="provider_reset_password"),
    path('addservicesfun/',AddServicesfun,name="addservices"),
    path('manage_services/',Manage_services,name="manage_services"),
    path('delete_service/<int:service_id>/',delete_service,name="delete_service")
]   