from .forms import *
from .accounts import *
from django.contrib import messages
# Create your views here.

def AddServicesfun(request):
    if request.session.get('provider')!=None:
        user = User.objects.get(email__iexact=request.session.get('provider_email'))
        if request.method == "POST":
            form = AddServicesForm(request.POST)
            if form.is_valid():
                temp = form.save(commit=False)
                temp.provider = user.provider_admin
                temp.save()
                return redirect('Provider:manage_services')
            else:
                messages.error(request,"Something went wrong")
                return redirect('Provider:addservices')
        else:
            form = AddServicesForm()
        if Provider_admin_profile.objects.filter(image=user.provider_admin.provider_admin_profile.image).exists():
            image_data = user.provider_admin.provider_admin_profile.image.url
        else:
            pass
        template = "Provider/Services/addservices.html"
        return render(request,template,{'form':form,"img":image_data})
    else:
        return redirect('Provider:provider_login')
    
def Manage_services(request):
    if request.session.get('provider') != None:
        user = User.objects.get(email__iexact = request.session.get('provider_email'))
        services = AddServices.objects.filter(provider=user.provider_admin)
        if Provider_admin_profile.objects.filter(image=user.provider_admin.provider_admin_profile.image).exists():
            image_data = user.provider_admin.provider_admin_profile.image.url
        else:
            pass

        template = "Provider/Services/manage_services.html"
        return render(request,template,{'services':services,"img":image_data})
    else:
        return redirect('Provider:provider_login')


def delete_service(request,service_id):
    if request.session.get('provider')!= None:
        user = User.objects.get(email__iexact=request.session.get('provider_email'))
        services = AddServices.objects.get(pk = service_id)
        services.delete()
        messages.success(request,"Service deleted")
        return redirect('Provider:manage_services')
    else:
        return redirect('Provider:provider_login')