from django.shortcuts import render, redirect
from .forms import *
from django.contrib import messages
from django.contrib.auth import authenticate
from django.conf import settings
from django.core.mail import send_mail
from django.contrib.auth.hashers import check_password
import random
# Create your views here.

def admin_register(request):
    if request.session.get('admin') != None:
        return redirect('Admin:admin_profile')
    if request.method == "POST":
        form = admin_signup_form(request.POST)
        if form.is_valid():
            if not User.objects.filter(email__iexact=form.cleaned_data['email']).exists():
                form.save()
                myuser = User.objects.get(username=form.cleaned_data['username'])
                myadmin = towing_admin(user=myuser)
                myadmin.save()
                myuser.is_active = False
                myuser.is_staff = False
                myuser.save()
                       #sending verfication mail
                subject = 'Account Verification Mail'
                message = f'Hello {myuser.username},\nEmail : {myuser.email}\nPlease verify your email id.. http://127.0.0.1:8000/admin1/admin_email_verification/'
                email_from = settings.EMAIL_HOST_USER
                email_to = [myuser.email, ]
                send_mail(subject, message, email_from, email_to)
                return redirect('Admin:admin_email_verification')
            else:
                messages.error(request,"Email address is already exists")
                return redirect('Admin:admin_register')            
        else:
            messages.error(request,"Something went wrong")
    else:
        form = admin_signup_form()
    template = "admin/accounts/admin_signup.html"
    return render(request,template,{'form':form})

def admin_email_verification(request):
    if request.session.get('admin') == None:
        if request.method == "POST":
            vef = Verification_Email_Form(request.POST)
            if vef.is_valid():
                form_email = vef.cleaned_data['email']
                try:
                    user_by_email = User.objects.get(email__iexact = form_email)
                    if user_by_email.is_active:
                        messages.error(request,'User is already verified, Please login!')
                        return redirect('Admin:admin_login')
                    else:
                        user_by_email.is_active = True
                        user_by_email.is_staff = True
                        user_by_email.save()
                        messages.success(request,"User activation succesfull. Please login!")
                        return redirect("Admin:admin_login")
                except:
                    messages.error(request,"User not found with this email address, Please try again or signup!")
                    return redirect('Admin:admin_email_verification')
            else:
                messages.error(request,"Something went wrong!!")
        else:
            vef = Verification_Email_Form()
        template = "admin/accounts/admin_email_verification.html"
        return render(request,template,{'form':vef})
    else:
        return redirect('Admin:admin_login')

def admin_login(request):
    if request.session.get('admin') == None:
        if request.method == "POST":
            form = Login_form(request=request, data=request.POST)
            if form.is_valid():
                username = form.cleaned_data['username']
                password = form.cleaned_data['password']
                user = authenticate(username=username,password=password)
                if user is not None:
                    user = User.objects.get(username = user)
                    if user.is_active == True:
                        user_admin = {
                            'username' : user.username,
                            'email' : user.email
                        }
                        request.session['admin'] = user_admin
                        request.session['admin_email'] = user.email
                        if request.session.get('admin') != None:
                            return redirect('Admin:admin_profile')
                        else:
                            return redirect('Admin:admin_login')
                    else:
                        user.delete()
                        messages.error(request,'User not found or authenticated, please signup again!')
                        return redirect('Admin:signup')
                else:
                    messages.error(request,"Provided Id and Password is wrong!")
                messages.success(request,'Logged in Successfully!!')
            else:
                messages.error(request,"Something went wrong!!!")
        else:
            form = Login_form()
        template = "admin/accounts/admin_login.html"
        return render(request,template,{'form':form})
    else:
        return redirect('Admin:admin_profile')

def admin_logout(request):
    if request.session.get('admin') == None:
        return redirect('Admin:admin_login')
    else:
        request.session.delete()
        return redirect('Admin:admin_login')
    
def admin_set_password(request):
    if request.session.get('admin') != None:
        user = User.objects.get(email__iexact = request.session.get('admin_email'))
        if request.method == "POST":
            old = request.POST.get('old')
            new = request.POST.get('new')
            confirm = request.POST.get('confirm')
            if new == confirm:
                if check_password(old,user.password):
                    user.set_password(new)
                    user.save()
                    messages.success(request,'Password has been changed successfully!')
                    return redirect('Admin:admin_profile')
                else:
                    messages.error(request,"Old password is wrong.")
                    return redirect('Admin:admin_set_password')
            else:
                messages.error(request,"New and Confirm password are not same!")
                return redirect('Admin:admin_set_password')
        else:
            pass
        template = "admin/accounts/admin_set_password.html"
        return render(request,template)
    else:
        return redirect('Admin:admin_login')


def admin_forgot_password_function(request):
    if request.session.get('admin') == None:
        if request.method == "POST":
            form = Forgot_password_form(request.POST)
            if form.is_valid():
                email = form.cleaned_data['email']
                if User.objects.filter(email__iexact = email).exists():
                    OTP = random.randint(111111,999999)
                    subject = 'Password Reset OTP'
                    message = f"Your OTP is, {OTP} \nPlease Follow This Link to verify OTP, --> http://127.0.0.1:8000/admin1/admin_verify_otp/"
                    email_from = settings.EMAIL_HOST_USER
                    email_to = [email, ]
                    send_mail(subject, message, email_from, email_to)
                    request.session['sent_otp'] = OTP
                    request.session['forgot_pw_email'] = email
                    return redirect('Admin:admin_verify_otp')
                else:
                    messages.error(request,"User with this email not found!")
                    return redirect('Admin:admin_forgot_password_function')
            else:
                messages.error(request,"Somthing went wrong")
                return redirect('Admin:admin_forgot_password_function')
        else:
            form = Forgot_password_form()
        template = "admin/accounts/admin_forgot_password.html"
        return render(request,template,{'form':form})
    else:
        return redirect('Admin:admin_profile')
    
def admin_verify_otp(request):
    if request.session.get('forgot_pw_email') != None :
        if request.method == "POST":
            otp = request.POST.get("otp")
            if otp:
                if otp == str(request.session.get('sent_otp')):
                    return redirect('Admin:admin_reset_password')
                else:
                    messages.error(request,"OTP does not match. Try again!")
                    return redirect('Admin:admin_verify_otp')
            else:
                messages.error(request,"Somthing went wrong")
                return redirect('Admin:admin_verify_otp')
        else:
            pass
        template = "admin/accounts/admin_verify_otp.html"
        return render(request,template)
    else:
        return redirect('Admin:admin_forgot_password_function')
    

def admin_reset_password(request):
    if request.session.get('forgot_pw_email') != None :
        user = User.objects.get(email__iexact = request.session.get('forgot_pw_email'))
        new = request.POST.get('new')
        confirm = request.POST.get('confirm')
        if request.method == "POST":
            if new == confirm:
                user.set_password(new)
                user.save()
                messages.success(request,'Password has been changed successfully!')
                return redirect('Admin:admin_login')
            else:
                messages.error(request,"New and Confirm password are not same!")
                return redirect('Admin:admin_reset_password')
        else:
            pass
        template = "admin/accounts/admin_reset_password.html"
        return render(request,template)
    else:
        return redirect('Admin:admin_forgot_password_function')
    
def admin_profile(request):
    if request.session.get('admin') != None:
        user = User.objects.get(email__iexact = request.session.get('admin_email'))
        if request.method == "POST":
            user_form = admin_user_form(request.POST,instance=user)
            profile_form = Towing_admin_profile_form(request.POST,request.FILES,instance=user.towing_admin.towing_admin_profile)
            if user_form.is_valid() and profile_form.is_valid():
                user_form.save()
                profile_form.save()
                messages.success(request,"Profile updated successfully!")
                return redirect("Admin:admin_profile")
            else:
                print(user_form.is_valid())
                print(profile_form.is_valid())
                messages.error(request,"Something went wrong")
                return redirect("Admin:admin_profile")
        else:
            user_form = admin_user_form(instance=user)
            profile_form = Towing_admin_profile_form(instance=user.towing_admin.towing_admin_profile)
        image_data = None
        try:
            if Towing_admin_profile.objects.filter(image=user.towing_admin.towing_admin_profile.image).exists():
                image_data = user.towing_admin.towing_admin_profile.image.url
        except:
            pass
        context = {
            'user_form' : user_form,
            'profile_form' : profile_form,
            "img":image_data
        }
        return render(request,"admin/accounts/admin_profile.html",context)
    else:
        return redirect('Admin:admin_login')