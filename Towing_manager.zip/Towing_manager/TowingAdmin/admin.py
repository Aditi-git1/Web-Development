from django.contrib import admin
from .models import *
# Register your models here.

admin.site.register(towing_admin)
admin.site.register(Towing_admin_profile)
admin.site.register(area_data)
admin.site.register(add_number_plate)
admin.site.register(Master_data)
