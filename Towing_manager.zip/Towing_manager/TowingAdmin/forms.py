from django import forms
from .models import *
from django.contrib.auth.forms import UserCreationForm, AuthenticationForm
from django.contrib.auth.models import User

class admin_signup_form(UserCreationForm):
    username = forms.CharField(required=True,widget=forms.TextInput(attrs={
        'class':"form-control",
        'id':"login-name",
        'placeholder':"Username",
        'style':"border-radius: 10px;"
    }))
    email = forms.EmailField(required=True,widget=forms.EmailInput(attrs={
        'class':"form-control",
        'id':"login-name",
        'placeholder':"Email",
        'style':"border-radius: 10px;"
    }))
    password1 = forms.CharField(required=True,widget=forms.PasswordInput(attrs={
        'class':"form-control",
        'id':"login-name",
        'placeholder':"Password",
        'style':"border-radius: 10px;"
    }))
    password2 = forms.CharField(required=True,widget=forms.PasswordInput(attrs={
        'class':"form-control",
        'id':"login-name",
        'placeholder':"Confirm Password",
        'style':"border-radius: 10px;"
    }))
    class Meta:
        model = User
        fields = ['username','email','password1','password2']

class Login_form(AuthenticationForm):
    username = forms.CharField(required=True,label_suffix="", widget=forms.TextInput(attrs={
        'id':"form3Example1cg",
        'class':"form-control form-control-lg",
        'placeholder' : 'Enter your Username'
    }))
    password = forms.CharField(required=True, label="Password", label_suffix="", widget=forms.PasswordInput(attrs={
        'id':"form3Example1cg",
        'class':"form-control form-control-lg",
        'placeholder' : 'Enter your Password'
    }))
    class Meta:
        model = User
        fields = ['username']

class Verification_Email_Form(forms.ModelForm):
    email = forms.EmailField(required=True,widget=forms.EmailInput(attrs={
        'class':"form-control",
        'id':"login-name",
        'placeholder':"Email",
        'style':"border-radius: 10px;"
    }))
    class Meta:
        model = User
        fields = ['email']


class Forgot_password_form(forms.ModelForm):
    email = forms.EmailField(required=True,widget=forms.EmailInput(attrs={
        'class':"form-control",
        'id':"login-name",
        'placeholder':"Email",
        'style':"border-radius: 10px;"
    }))
    class Meta:
        model = User
        fields = ['email']

class Towing_admin_profile_form(forms.ModelForm):
    class Meta:
        model = Towing_admin_profile
        exclude = ['user']
        widgets = {
            'gender': forms.Select(attrs={
                    'class':"form-control",
                    'id':"login-name",
                    'placeholder':"Gender",
                    'style':"border-radius: 10px;"
            }) ,
            'age': forms.NumberInput(attrs={
                    'class':"form-control",
                    'id':"login-name",
                    'placeholder':"Age",
                    'style':"border-radius: 10px;"
            }) ,
            'phone': forms.NumberInput(attrs={
                    'class':"form-control",
                    'id':"login-name",
                    'placeholder':"Phone",
                    'style':"border-radius: 10px;"
            }) ,
            'address': forms.Textarea(attrs={
                    'class':"form-control",
                    'id':"login-name",
                    'placeholder':"Address",
                    'style':"border-radius: 10px;"
            }) ,
            'area': forms.Select(attrs={
                    'class':"form-control",
                    'id':"login-name",
                    'placeholder':"Area",
                    'style':"border-radius: 10px;"
            }) ,
            'image' : forms.FileInput(attrs={
                    'class':"form-control",
                    'id':"login-name",
                    'placeholder':"Upload an Image",
                    'style':"border-radius: 10px;"
            })
        }

class admin_user_form(forms.ModelForm):
    username = forms.CharField(disabled=True,widget=forms.TextInput(attrs={
                    'class':"form-control",
                    'id':"login-name",
                    'placeholder':"Username",
                    'style':"border-radius: 10px;",
            }))
    email = forms.EmailField(disabled=True,widget=forms.EmailInput(attrs={
                    'class':"form-control",
                    'id':"login-name",
                    'placeholder':"Email",
                    'style':"border-radius: 10px;",
            }))
    class Meta:
        model = User
        fields = ['username','email','first_name','last_name']
        widgets = {
            'first_name': forms.TextInput(attrs={
                    'class':"form-control",
                    'id':"login-name",
                    'placeholder':"First Name",
                    'style':"border-radius: 10px;"
            }) ,
            'last_name': forms.TextInput(attrs={
                    'class':"form-control",
                    'id':"login-name",
                    'placeholder':"Last Name",
                    'style':"border-radius: 10px;"
            })
        }

class add_number_plate_form(forms.ModelForm):
    class Meta:
        model = add_number_plate
        exclude = ['admin_data','towed_date']
        widgets = {
            'number_plate': forms.TextInput(attrs={
                    'class':"form-control",
                    'id':"login-name",
                    'placeholder':"Number Plate",
                    'style':"border-radius: 10px; text-transform:uppercase;"
            }) ,
            'towed_from': forms.Textarea(attrs={
                    'class':"form-control",
                    'id':"login-name",
                    'placeholder':"Towed From",
                    'style':"border-radius: 10px;"
            }) ,
            'towed_from_area': forms.Select(attrs={
                    'class':"form-control",
                    'id':"login-name",
                    'placeholder':"Area",
                    'style':"border-radius: 10px;"
            }) ,
        }

    def clean_number_plate(self):
        data = self.cleaned_data['number_plate']
        data = data.upper()
        return data