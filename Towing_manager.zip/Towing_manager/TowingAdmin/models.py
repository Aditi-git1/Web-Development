from django.db import models
from django.contrib.auth.models import User
from django.db.models.signals import post_save
from django.dispatch import receiver
# Create your models here.

class area_data(models.Model):
    pincode = models.IntegerField()
    area = models.CharField(max_length=150)

    def __str__(self):
        return str(self.area)

Gender_choice = (
    ('Male','Male'),
    ('Female','Female')
)

class towing_admin(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE, primary_key=True)

    def __str__(self):
        return str(self.user)

class Towing_admin_profile(models.Model):
    user = models.OneToOneField(towing_admin, on_delete=models.CASCADE,primary_key=True)
    gender = models.CharField(max_length=10, choices=Gender_choice)
    age = models.IntegerField(default=18)
    phone = models.IntegerField(null=True,blank=True)
    address = models.TextField(null=True,blank=True)
    area = models.ForeignKey(area_data, on_delete=models.CASCADE,null=True,blank=True)
    image = models.ImageField(upload_to='Admin_profile/',null=True,blank=True)
    
    def __str__(self):
        return str(self.user)

@receiver(post_save, sender=towing_admin)
def create_Towing_admin_profile(sender, instance, created, **kwargs):
    if created:
        Towing_admin_profile.objects.create(user=instance)

@receiver(post_save, sender=towing_admin)
def save_user_Towing_admin_profile(sender, instance, **kwargs):
    instance.towing_admin_profile.save()


class add_number_plate(models.Model):
    admin_data = models.ForeignKey(Towing_admin_profile, on_delete=models.CASCADE)
    number_plate = models.CharField(max_length=12, primary_key=True)
    towed_from = models.CharField(max_length=200)
    towed_from_area = models.ForeignKey(area_data,on_delete=models.CASCADE)
    towed_date = models.DateField(auto_now_add=True)

    def __str__(self):
        return str(self.number_plate)

class Master_data(models.Model):
    number_plate= models.CharField(max_length=20)
    full_name = models.CharField(max_length=100)
    email = models.EmailField(max_length=254)
    gender = models.CharField(max_length=6,choices=Gender_choice)
    phone = models.IntegerField()
    address = models.TextField()
    area_name = models.ForeignKey(area_data,on_delete=models.CASCADE)
    chassis_number = models.CharField(max_length=50)
    vehicle_model = models.CharField(max_length=100)
    vehicle_type = models.CharField(max_length=50)

    def __str__(self):
        return (self.number_plate)
    