from django.urls import path
from .views import *

app_name = "Admin"

urlpatterns = [
    path('',show_details,name="show_details"),
    path('admin_register/',admin_register,name="admin_register"),
    path('admin_login/',admin_login,name="admin_login"),
    path('admin_profile/',admin_profile,name="admin_profile"),
    path('admin_email_verification/',admin_email_verification,name="admin_email_verification"),
    path('admin_logout/',admin_logout,name="admin_logout"),
    path('admin_set_password/',admin_set_password,name="admin_set_password"),
    path('admin_forgot_password_function/',admin_forgot_password_function,name="admin_forgot_password_function"),
    path('admin_verify_otp/',admin_verify_otp,name="admin_verify_otp"),
    path('admin_reset_password/',admin_reset_password,name="admin_reset_password"),
    path('add_number_plate/',add_number_plate_fun,name="add_number_plate"),
    path('show_owner_detail/<str:number_plate>/',show_owner_detail,name="show_owner_detail"),
    path('area_show/',area_show,name="area_show"),
    path('parking/',parking,name='parking'),
    path('customer_query/',customer_query,name='query'),
    path('user_payment_done/',user_payment_done,name='user_payment_done'),
    path('service_provider/',service_provider,name='service_provider')
]   