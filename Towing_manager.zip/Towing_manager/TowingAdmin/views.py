from .forms import *
from .accounts import *
from django.contrib import messages
from ParkingArea.models import parking_area
from Contact_us.models import *
from Payments.models import *
from ServiceProvider.models import *
import os
from twilio.rest import Client

def add_number_plate_fun(request):
    if request.session.get('admin') != None:
        user = User.objects.get(email__iexact = request.session.get('admin_email'))
        if request.method == "POST":
            form = add_number_plate_form(request.POST)
            if form.is_valid():
                temp = form.save(commit=False)
                temp.admin_data = user.towing_admin.towing_admin_profile
                temp.save()
                userdata = Master_data.objects.get(number_plate__iexact=temp.number_plate)
                msg = "\n\nHello "+ str(userdata.full_name).strip() +", From Towing Admin.\nYour vehicle has been towed because it was parked in no parking zone at: "+str(temp.towed_from).strip()+", "+str(temp.towed_from_area.area).strip()+", "+str(temp.towed_from_area.pincode).strip() +"\nFollow link to pay online: http://127.0.0.1:8000/search_result/?query="+ str(temp.number_plate).strip() +"\nPlease collect your vehicle and receipt in 3 working days."+ f"Police Station Name: {str(temp.admin_data.area).strip()} Police Station"+"\nHere is the Google map link for your convenience: https://www.google.co.in/maps/search/"+str(temp.admin_data.area).replace(" ", "").lower()+"+police+station/"
                account_sid = 'AC125baf10d23e118ec34874b5a49dd332'
                auth_token = 'fd87f63b099f62f81afc0dde1443f891'
                client = Client(account_sid, auth_token)
                message = client.messages.create(
                    body=msg,
                    from_='+14345108490',
                    to='+919409172899'
                )
                print('Message Sent :- ', message.sid)
                print(msg)
                return redirect('Admin:show_details')
            else:
                messages.error(request,"Form is not valid")
                return redirect("Admin:add_number_plate")
        else:
            form = add_number_plate_form()
        if Towing_admin_profile.objects.filter(image=user.towing_admin.towing_admin_profile.image).exists():
            image_data = user.towing_admin.towing_admin_profile.image.url
        else:
            pass
        template = "admin/add_number_plate.html"
        return render(request,template,{'form':form,"img":image_data})
    else:
        return redirect('Admin:admin_login')

def show_details(request):
    if request.session.get('admin') != None:
        user = User.objects.get(email__iexact = request.session.get('admin_email'))
        admin_towed_data = add_number_plate.objects.all()
        if Towing_admin_profile.objects.filter(image=user.towing_admin.towing_admin_profile.image).exists():
            image_data = user.towing_admin.towing_admin_profile.image.url
        else:
            pass
        template = "admin/show_towing_details.html"
        return render(request,template,{'admin_towed_data':admin_towed_data,"img":image_data})
    else:
        return redirect('Admin:admin_login')

def show_owner_detail(request, number_plate):
    if request.session.get('admin') != None:
        user = User.objects.get(email__iexact = request.session.get('admin_email'))
        owner_detail = Master_data.objects.get(number_plate__iexact=number_plate)
        if Towing_admin_profile.objects.filter(image=user.towing_admin.towing_admin_profile.image).exists():
            image_data = user.towing_admin.towing_admin_profile.image.url
        else:
            pass
        template = "admin/show_owner_details.html"
        return render(request,template,{'i':owner_detail,"img":image_data})
    else:
        return redirect('Admin:admin_login')

def area_show(request):
    if request.session.get('admin') != None:
        user = User.objects.get(email__iexact = request.session.get('admin_email'))
        pincode = area_data.objects.all()
        if Towing_admin_profile.objects.filter(image=user.towing_admin.towing_admin_profile.image).exists():
            image_data = user.towing_admin.towing_admin_profile.image.url
        else:
            pass
        return render(request,'admin/OtherDetails/area_show.html',{'pincode':pincode,"img":image_data})
    else:
        return redirect('Admin:admin_login')

def parking(request):
    if request.session.get('admin') != None:
        user = User.objects.get(email__iexact = request.session.get('admin_email'))
        parking_zone = parking_area.objects.all()
        if Towing_admin_profile.objects.filter(image=user.towing_admin.towing_admin_profile.image).exists():
            image_data = user.towing_admin.towing_admin_profile.image.url
        else:
            pass
        return render(request,'admin/OtherDetails/parking_area.html',{'parking_zone':parking_zone,"img":image_data})
    else:
        return redirect('Admin:admin_login')

def customer_query(request):
    if request.session.get('admin') != None:
        user = User.objects.get(email__iexact = request.session.get('admin_email'))
        profile = Towing_admin_profile.objects.get(user=user.towing_admin.towing_admin_profile)
        try:
            if ContactUs.objects.filter(area__area__iexact = profile.area.area).exists:
                contact_show = ContactUs.objects.filter(area__area__iexact = profile.area.area)
            else:
                contact_show = ContactUs.objects.all()
        except:
            contact_show = ContactUs.objects.all()
        if Towing_admin_profile.objects.filter(image=user.towing_admin.towing_admin_profile.image).exists():
            image_data = user.towing_admin.towing_admin_profile.image.url
        else:
            pass
        return render(request,'admin/OtherDetails/customer_query.html',{'show':contact_show,"img":image_data})
    else:
        return redirect('Admin:admin_login')

def user_payment_done(request):
    if request.session.get('admin') != None:
        user = User.objects.get(email__iexact = request.session.get('admin_email'))
        profile = Towing_admin_profile.objects.get(user=user.towing_admin.towing_admin_profile)
        try:
            if paid_data_users.objects.filter(towed_from_area__icontains = profile.area.area).exists:
                contact_show = paid_data_users.objects.filter(towed_from_area__iexact = profile.area.area)
                contact_show = Master_data.objects.filter(number_plate__in=contact_show)
            else:
                contact_show = paid_data_users.objects.all()
        except:
            contact_show = paid_data_users.objects.all()
        # contact_show = paid_data_users.objects.all()
        # contact_show = Master_data.objects.filter(number_plate__in=contact_show)
        if Towing_admin_profile.objects.filter(image=user.towing_admin.towing_admin_profile.image).exists():
            image_data = user.towing_admin.towing_admin_profile.image.url
        else:
            pass
        return render(request,'admin/OtherDetails/payment_done_show.html',{'payments_show':contact_show,"img":image_data})
    else:
        return redirect('Admin:admin_login')

def service_provider(request):
    if request.session.get('admin') != None:
        user = User.objects.get(email__iexact = request.session.get('admin_email'))
        sp = Provider_admin_profile.objects.all()
        if Towing_admin_profile.objects.filter(image=user.towing_admin.towing_admin_profile.image).exists():
            image_data = user.towing_admin.towing_admin_profile.image.url
        else:
            pass
        return render(request,'admin/OtherDetails/service_provider.html',{'pincode':sp,"img":image_data})
    else:
        return redirect('Admin:admin_login')
        